<template>
	<div class="page subpage">
		<p>积分商城</p>
	</div>
</template>

<script>
</script>

<style>
</style>